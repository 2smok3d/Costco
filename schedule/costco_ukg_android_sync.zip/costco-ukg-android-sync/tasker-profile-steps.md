# Tasker Profile: UKG Screenshot Watcher

## Goal

When a new UKG screenshot appears in:

/Pictures/UKG_Schedule/

Tasker OCRs it and sends the text to Google Apps Script, which creates Google Calendar events.

---

## Part 1 — Create folder

On Android, create:

/Pictures/UKG_Schedule/

You can use the Files app.

---

## Part 2 — Create Google Apps Script webhook

1. Go to script.google.com
2. New project
3. Paste the code from:

google-apps-script-calendar-webhook.js

4. Save as:

Costco Calendar Webhook

5. Deploy → New deployment
6. Type: Web app
7. Execute as: Me
8. Who has access: Anyone with the link
9. Deploy
10. Copy the Web App URL

You will paste this URL into Tasker.

---

## Part 3 — Create Tasker profile

Open Tasker.

### Profile

1. Profiles tab
2. Tap +
3. Event
4. File Modified
5. Dir:

/storage/emulated/0/Pictures/UKG_Schedule/

6. Event: Created or Modified
7. Go back
8. New Task: `UKG OCR To Calendar`

---

## Part 4 — Task actions

### Action 1: Wait

Task:
- Wait: 2 seconds

This gives Android time to finish saving the screenshot.

---

### Action 2: List Files

Action:
- File → List Files

Settings:
- Dir: `/storage/emulated/0/Pictures/UKG_Schedule/`
- Match: `*.png/*.jpg/*.jpeg`
- Sort Select: Modification Date, Reverse
- Variable Array: `%ukgfiles`

This gets the newest screenshot.

---

### Action 3: Variable Set

Action:
- Variables → Variable Set

Name:
`%latest`

To:
`%ukgfiles1`

---

### Action 4: OCR image

Use whichever OCR action your Tasker has.

Possible names depending on your setup:
- Get Screen Info
- AutoTools OCR
- OCR Image
- Recognize Text

Input image:
`%latest`

Output variable:
`%ocrtext`

If using AutoTools OCR:
- Image: `%latest`
- Result variable usually becomes `%atocrvalue`

Then add:
Variable Set:
- Name: `%ocrtext`
- To: `%atocrvalue`

---

### Action 5: HTTP Request

Action:
- Net → HTTP Request

Method:
POST

URL:
Paste your Google Apps Script Web App URL

Headers:
Content-Type: application/json

Body:

{
  "timezone": "America/Phoenix",
  "text": "%ocrtext"
}

Output variable:
`%response`

---

### Action 6: Flash result

Action:
- Alert → Flash

Text:
`UKG calendar sync response: %response`

---

## Optional: only process files with UKG in name

If your screenshots are mixed with other screenshots, make a separate folder manually.

Recommended:

/Pictures/UKG_Schedule/

Only put UKG screenshots in that folder.

---

## Testing

Use this test text by manually setting `%ocrtext` first:

Mon May 25 10:00 AM - 6:30 PM
Sun May 31 8:00 AM - 4:30 PM

Run the task.

Check Google Calendar → Costco Work.

---

## Troubleshooting

### No event created

Check:
- Apps Script deployment is Web App
- Access is Anyone with link
- Calendar permission accepted
- OCR text actually contains date and time

### Wrong year

The parser uses the current year if no year appears in OCR text.

### Duplicates

The script tries to skip duplicates using title + start + end.

### OCR is messy

Take screenshot in weekly view with:
- date visible
- full start/end time visible
- no overlapping popups