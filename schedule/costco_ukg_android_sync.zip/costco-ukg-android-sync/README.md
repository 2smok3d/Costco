# Costco UKG Screenshot → Google Calendar Sync

This setup lets you take a screenshot of your UKG schedule on Android, OCR the text, and send shift data to Google Calendar.

It does NOT log into UKG or scrape UKG directly.

## What you need

- Android phone
- Tasker
- Google Calendar
- Google account
- Optional: AutoTools OCR / Tasker OCR plugin if your Tasker install does not have OCR

## Recommended calendar

Create a Google Calendar named:

Costco Work

## Folder to use

Make this folder on your phone:

/Pictures/UKG_Schedule/

Save or move UKG schedule screenshots there.

## Setup overview

1. Deploy the Google Apps Script in `google-apps-script-calendar-webhook.js`
2. Copy the Web App URL
3. Create the Tasker profile from `tasker-profile-steps.md`
4. Paste your Web App URL into the Tasker HTTP Request action
5. Take a UKG schedule screenshot
6. Tasker OCRs it and creates Google Calendar shifts

## Color logic

The Apps Script uses calendar event colors:

- Sunday shift: yellow
- Opening shift: green
- Closing shift: purple
- Holiday: red
- Normal shift: blue

## Important

OCR is never perfect. Always check the created calendar events the first few times.