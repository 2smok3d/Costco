/**
 * Costco UKG Screenshot OCR -> Google Calendar webhook
 *
 * Deploy as:
 * Extensions / Apps Script -> Deploy -> New deployment -> Web app
 *
 * Execute as: Me
 * Who has access: Anyone with the link
 *
 * Paste the deployment URL into Tasker HTTP Request.
 */

const CALENDAR_NAME = "Costco Work";

// Optional secret. If you set this, Tasker must send the same secret.
// Leave blank for easiest setup.
const SECRET = "";

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || "{}");

    if (SECRET && body.secret !== SECRET) {
      return jsonOut({ ok: false, error: "Bad secret" });
    }

    const rawText = body.text || "";
    const timezone = body.timezone || Session.getScriptTimeZone() || "America/Phoenix";

    const shifts = parseShifts(rawText, timezone);

    if (!shifts.length) {
      return jsonOut({
        ok: false,
        error: "No shifts found",
        rawText
      });
    }

    const calendar = getOrCreateCalendar(CALENDAR_NAME);
    const created = [];

    shifts.forEach(shift => {
      const title = buildTitle(shift);
      const description =
        "Created from UKG screenshot OCR.\n\nRaw OCR:\n" + rawText.substring(0, 3000);

      // Avoid duplicates: same title, start, end.
      const existing = calendar.getEvents(shift.start, shift.end, { search: title });
      if (existing.length > 0) {
        created.push({ title, start: shift.start, end: shift.end, skipped: true });
        return;
      }

      const event = calendar.createEvent(title, shift.start, shift.end, {
        description,
        location: "Costco"
      });

      event.setColor(getColor(shift));
      created.push({ title, start: shift.start, end: shift.end, skipped: false });
    });

    return jsonOut({ ok: true, count: created.length, events: created });

  } catch (err) {
    return jsonOut({ ok: false, error: String(err), stack: err.stack });
  }
}

function getOrCreateCalendar(name) {
  const cals = CalendarApp.getCalendarsByName(name);
  if (cals.length) return cals[0];
  return CalendarApp.createCalendar(name);
}

function parseShifts(text, timezone) {
  const clean = normalizeText(text);
  const lines = clean.split("\n").map(x => x.trim()).filter(Boolean);
  const shifts = [];

  /**
   * Supported examples:
   * Mon May 25 10:00 AM - 6:30 PM
   * Monday 5/25 10:00am-6:30pm
   * 5/25/2026 10:00 AM - 6:30 PM
   * Sun 05/31 8:00 AM - 4:30 PM
   */

  const dateTimeRegexes = [
    /(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\s+)?([A-Za-z]{3,9})\s+(\d{1,2})(?:,\s*(\d{4}))?\s+(\d{1,2})(?::(\d{2}))?\s*(AM|PM|am|pm)\s*[-–to]+\s*(\d{1,2})(?::(\d{2}))?\s*(AM|PM|am|pm)/i,
    /(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\s+)?(\d{1,2})[\/\-](\d{1,2})(?:[\/\-](\d{2,4}))?\s+(\d{1,2})(?::(\d{2}))?\s*(AM|PM|am|pm)\s*[-–to]+\s*(\d{1,2})(?::(\d{2}))?\s*(AM|PM|am|pm)/i
  ];

  for (const line of lines) {
    let found = false;

    for (const rx of dateTimeRegexes) {
      const m = line.match(rx);
      if (!m) continue;

      let month, day, year, startHour, startMin, startMer, endHour, endMin, endMer;
      let dayName = m[1] || "";

      if (isNaN(Number(m[2]))) {
        month = monthNameToNumber(m[2]);
        day = Number(m[3]);
        year = m[4] ? Number(m[4]) : new Date().getFullYear();
        startHour = Number(m[5]);
        startMin = Number(m[6] || "0");
        startMer = m[7];
        endHour = Number(m[8]);
        endMin = Number(m[9] || "0");
        endMer = m[10];
      } else {
        month = Number(m[2]);
        day = Number(m[3]);
        year = m[4] ? normalizeYear(Number(m[4])) : new Date().getFullYear();
        startHour = Number(m[5]);
        startMin = Number(m[6] || "0");
        startMer = m[7];
        endHour = Number(m[8]);
        endMin = Number(m[9] || "0");
        endMer = m[10];
      }

      const start = makeDate(year, month, day, startHour, startMin, startMer);
      let end = makeDate(year, month, day, endHour, endMin, endMer);

      // Handles overnight shifts.
      if (end <= start) {
        end = new Date(end.getTime() + 24 * 60 * 60 * 1000);
      }

      shifts.push({
        sourceLine: line,
        dayName,
        start,
        end,
        isSunday: start.getDay() === 0,
        isOpening: start.getHours() <= 6,
        isClosing: end.getHours() >= 21 || end.getHours() < 2,
        isHoliday: /holiday/i.test(line)
      });

      found = true;
      break;
    }

    if (found) continue;
  }

  return shifts;
}

function normalizeText(text) {
  return String(text || "")
    .replace(/\r/g, "\n")
    .replace(/[|]/g, " ")
    .replace(/[—–]/g, "-")
    .replace(/\bto\b/gi, "-")
    .replace(/\s+/g, " ")
    .replace(/(Mon|Tue|Wed|Thu|Fri|Sat|Sun|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)/gi, "\n$1")
    .trim();
}

function monthNameToNumber(name) {
  const m = {
    jan:1, january:1,
    feb:2, february:2,
    mar:3, march:3,
    apr:4, april:4,
    may:5,
    jun:6, june:6,
    jul:7, july:7,
    aug:8, august:8,
    sep:9, sept:9, september:9,
    oct:10, october:10,
    nov:11, november:11,
    dec:12, december:12
  };
  return m[String(name).toLowerCase()] || new Date().getMonth() + 1;
}

function normalizeYear(y) {
  if (y < 100) return 2000 + y;
  return y;
}

function makeDate(year, month, day, hour, min, meridian) {
  hour = Number(hour);
  min = Number(min || 0);
  meridian = String(meridian || "").toUpperCase();

  if (meridian === "PM" && hour !== 12) hour += 12;
  if (meridian === "AM" && hour === 12) hour = 0;

  return new Date(year, month - 1, day, hour, min, 0);
}

function buildTitle(shift) {
  if (shift.isHoliday) return "Costco Holiday Shift";
  if (shift.isSunday) return "Costco Sunday Premium Shift";
  if (shift.isOpening) return "Costco Opening Shift";
  if (shift.isClosing) return "Costco Closing Shift";
  return "Costco Shift";
}

function getColor(shift) {
  // Google Calendar EventColor IDs:
  // 1 Lavender, 2 Sage, 3 Grape, 4 Flamingo, 5 Banana, 6 Tangerine,
  // 7 Peacock, 8 Graphite, 9 Blueberry, 10 Basil, 11 Tomato
  if (shift.isHoliday) return CalendarApp.EventColor.RED;
  if (shift.isSunday) return CalendarApp.EventColor.YELLOW;
  if (shift.isOpening) return CalendarApp.EventColor.GREEN;
  if (shift.isClosing) return CalendarApp.EventColor.PURPLE;
  return CalendarApp.EventColor.BLUE;
}

function jsonOut(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj, null, 2))
    .setMimeType(ContentService.MimeType.JSON);
}